-- --------------------------------------------------------
-- Host:                         qn0cquuabmqczee2.cbetxkdyhwsb.us-east-1.rds.amazonaws.com
-- Versión del servidor:         5.7.33-log - Source distribution
-- SO del servidor:              Linux
-- HeidiSQL Versión:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Volcando estructura de base de datos para kewm5ox2pgtfdasa
CREATE DATABASE IF NOT EXISTS `kewm5ox2pgtfdasa` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `kewm5ox2pgtfdasa`;

-- Volcando estructura para tabla kewm5ox2pgtfdasa.role
CREATE TABLE IF NOT EXISTS `role` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(128) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `enabled` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_administration_branch
CREATE TABLE IF NOT EXISTS `sh_administration_branch` (
  `id` int(11) unsigned NOT NULL,
  `name` varchar(256) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Table to store all the branches of a given company or business';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_administration_user_branch
CREATE TABLE IF NOT EXISTS `sh_administration_user_branch` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `id_user` int(10) unsigned NOT NULL DEFAULT '0',
  `id_branch` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_user_branch_branch` (`id_branch`),
  KEY `fk_user_branch_user` (`id_user`),
  CONSTRAINT `fk_user_branch_branch` FOREIGN KEY (`id_branch`) REFERENCES `sh_administration_branch` (`id`),
  CONSTRAINT `fk_user_branch_user` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Holds the data to know which user has permissions to interact with which branch';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_cash_transaction
CREATE TABLE IF NOT EXISTS `sh_cash_transaction` (
  `transaction_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `amount` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
  `transaction_type_id` smallint(5) unsigned NOT NULL DEFAULT '0' COMMENT 'FK - Tipos de transacciones para diferentes cajas',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `transaction_concept_id` smallint(6) unsigned NOT NULL DEFAULT '0' COMMENT 'FK - Concepto que lleva a la transacción',
  `note` text,
  `created_user_id` bigint(20) DEFAULT '0',
  `enabled` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `payment_method_id` smallint(5) unsigned NOT NULL DEFAULT '1',
  `id_branch` int(11) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`transaction_id`),
  KEY `fk_transaction_type` (`transaction_type_id`),
  KEY `fk_transaction_concept` (`transaction_concept_id`),
  KEY `fk_payment_method` (`payment_method_id`),
  KEY `fk_branch` (`id_branch`) USING BTREE,
  CONSTRAINT `fk_payment_method` FOREIGN KEY (`payment_method_id`) REFERENCES `sh_tab_payment_methods` (`payment_method_id`),
  CONSTRAINT `fk_transaction_branch` FOREIGN KEY (`id_branch`) REFERENCES `sh_administration_branch` (`id`),
  CONSTRAINT `fk_transaction_concept` FOREIGN KEY (`transaction_concept_id`) REFERENCES `sh_tab_transaction_concept` (`transaction_concept_id`),
  CONSTRAINT `fk_transaction_type` FOREIGN KEY (`transaction_type_id`) REFERENCES `sh_tab_transaction_type` (`transaction_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12861 DEFAULT CHARSET=latin1 COMMENT='Tabla para guardar transacciones del módulo CASH';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_fix_client
CREATE TABLE IF NOT EXISTS `sh_fix_client` (
  `client_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) NOT NULL,
  `apellido` varchar(255) NOT NULL,
  `dni` int(11) NOT NULL,
  `telefono` bigint(20) DEFAULT '0',
  `telefono2` bigint(20) unsigned DEFAULT '0',
  `direccion` varchar(64) DEFAULT NULL,
  `usuario` bigint(20) unsigned DEFAULT NULL,
  `email` varchar(63) DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  `fecha_modificacion` timestamp NULL DEFAULT NULL,
  `usuario_creador` bigint(20) DEFAULT NULL,
  `usuario_modificador` bigint(20) DEFAULT NULL,
  `habilitado` int(1) DEFAULT '1',
  `eliminado` int(1) DEFAULT '0',
  `birth_date` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`client_id`),
  UNIQUE KEY `dni_UNIQUE` (`dni`),
  UNIQUE KEY `usuario_UNIQUE` (`usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=4139 DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_fix_repair
CREATE TABLE IF NOT EXISTS `sh_fix_repair` (
  `repair_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `client_id` bigint(20) NOT NULL,
  `marca` varchar(256) DEFAULT '',
  `tipo_equipo` int(2) unsigned NOT NULL DEFAULT '0',
  `modelo` varchar(256) DEFAULT NULL,
  `imei` varchar(256) DEFAULT '',
  `problema` varchar(2048) DEFAULT NULL,
  `nota` varchar(2048) DEFAULT NULL,
  `id_status` int(11) unsigned NOT NULL,
  `fecha_ingreso` datetime NOT NULL,
  `fecha_ultima_actualizacion` datetime NOT NULL,
  `fecha_reparacion_terminada` datetime DEFAULT NULL,
  `senia_reparacion` decimal(10,0) DEFAULT '0',
  `precio_reparacion` decimal(10,0) DEFAULT '0',
  `costo_reparacion` decimal(10,0) DEFAULT '0',
  `usuario_creador` bigint(20) DEFAULT NULL,
  `usuario_modificador` bigint(20) DEFAULT NULL,
  `fecha_creacion` timestamp NULL DEFAULT NULL,
  `fecha_modificacion` timestamp NULL DEFAULT NULL,
  `habilitado` int(1) DEFAULT '1',
  `eliminado` int(1) DEFAULT '0',
  `encendido` int(1) NOT NULL DEFAULT '0' COMMENT 'Determina si el móvil fue entregado encendido (1) o apagado (0) al momento de dejarlo en el negocio',
  `warranty_term` int(10) unsigned DEFAULT '3',
  PRIMARY KEY (`repair_id`),
  KEY `fk_status_idx` (`id_status`),
  KEY `fk_cliente_idx` (`client_id`),
  CONSTRAINT `fk_status` FOREIGN KEY (`id_status`) REFERENCES `sh_fix_tab_status` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=35104 DEFAULT CHARSET=latin1 COMMENT='Tabla para almacenar los registros de reparaciones de Brillante Store';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_fix_repair_status_history
CREATE TABLE IF NOT EXISTS `sh_fix_repair_status_history` (
  `repair_status_history_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `repair_id` bigint(20) unsigned DEFAULT NULL,
  `status_id` varchar(45) NOT NULL,
  `created_date_tz` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `modified_date_tz` timestamp NULL DEFAULT NULL,
  `modified_user_id` bigint(20) DEFAULT NULL,
  `repair_cost` decimal(10,2) DEFAULT '0.00',
  `repair_price` decimal(10,2) DEFAULT '0.00',
  `repair_pay_in_advance` decimal(10,2) DEFAULT '0.00',
  `note` text,
  `id_branch` int(11) DEFAULT '1',
  PRIMARY KEY (`repair_status_history_id`),
  KEY `repair_id_idx` (`repair_id`),
  KEY `fk_repair_history_branch` (`id_branch`),
  CONSTRAINT `repair_id` FOREIGN KEY (`repair_id`) REFERENCES `sh_fix_repair` (`repair_id`) ON DELETE CASCADE ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=17849 DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_fix_tab_status
CREATE TABLE IF NOT EXISTS `sh_fix_tab_status` (
  `id` int(11) unsigned NOT NULL,
  `status` varchar(63) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `status_UNIQUE` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_fix_transaction
CREATE TABLE IF NOT EXISTS `sh_fix_transaction` (
  `repair_transaction_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `repair_id` bigint(20) unsigned NOT NULL,
  `transaction_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`repair_transaction_id`),
  KEY `fk_repair` (`repair_id`),
  KEY `fk_transaction_repair` (`transaction_id`),
  CONSTRAINT `fk_repair` FOREIGN KEY (`repair_id`) REFERENCES `sh_fix_repair` (`repair_id`) ON DELETE CASCADE,
  CONSTRAINT `fk_transaction_repair` FOREIGN KEY (`transaction_id`) REFERENCES `sh_cash_transaction` (`transaction_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3513 DEFAULT CHARSET=latin1 COMMENT='Tabla intermedia para vincular transacciones monetarias (cash_transaction) con arreglo de equipos (fix)';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_tab_payment_methods
CREATE TABLE IF NOT EXISTS `sh_tab_payment_methods` (
  `payment_method_id` smallint(5) unsigned NOT NULL DEFAULT '0',
  `description` varchar(128) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`payment_method_id`),
  UNIQUE KEY `description_UNIQUE` (`description`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Tabla para almacenar los métodos de pago soportados por la empresa';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_tab_transaction_concept
CREATE TABLE IF NOT EXISTS `sh_tab_transaction_concept` (
  `transaction_concept_id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(256) NOT NULL,
  `transaction_parent_concept_id` smallint(5) unsigned DEFAULT NULL,
  `transaction_type_id` smallint(5) unsigned DEFAULT NULL COMMENT '0 -> Egreso; 1 -> Ingreso',
  `user_assignable` smallint(6) NOT NULL DEFAULT '1',
  `enabled` tinyint(3) unsigned DEFAULT '1' COMMENT '0 -> Deshabilitado; 1 -> Habilitado',
  `modifiable` tinyint(3) unsigned DEFAULT '1' COMMENT '0 -> No modificable; 1 -> Modificable',
  PRIMARY KEY (`transaction_concept_id`),
  KEY `fk_transaction_parent_concept_id` (`transaction_parent_concept_id`),
  CONSTRAINT `fk_transaction_parent_concept_id` FOREIGN KEY (`transaction_parent_concept_id`) REFERENCES `sh_tab_transaction_concept` (`transaction_concept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=363 DEFAULT CHARSET=latin1 COMMENT='Conceptos que originan transacciones de dinero (Tabla de lookup)';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.sh_tab_transaction_type
CREATE TABLE IF NOT EXISTS `sh_tab_transaction_type` (
  `transaction_type_id` smallint(5) unsigned NOT NULL,
  `description` varchar(256) NOT NULL,
  PRIMARY KEY (`transaction_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Tipos de transacciones, para poder dividir entre diferentes cajas que administran dinero en efectivo, electrónico, o según algún concepto particular.';

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.user
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `last_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `user_name` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `role_id` int(10) unsigned NOT NULL DEFAULT '0',
  `password` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enabled` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

-- La exportación de datos fue deseleccionada.

-- Volcando estructura para tabla kewm5ox2pgtfdasa.user_role
CREATE TABLE IF NOT EXISTS `user_role` (
  `id_user` int(10) unsigned NOT NULL,
  `id_role` int(10) unsigned NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `enabled` tinyint(3) unsigned NOT NULL DEFAULT '1',
  `deleted` tinyint(3) unsigned NOT NULL DEFAULT '0',
  KEY `fk_user_id` (`id_user`),
  KEY `fk_role_id` (`id_role`),
  CONSTRAINT `fk_role_id` FOREIGN KEY (`id_role`) REFERENCES `role` (`id`),
  CONSTRAINT `fk_user_id` FOREIGN KEY (`id_user`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- La exportación de datos fue deseleccionada.

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
